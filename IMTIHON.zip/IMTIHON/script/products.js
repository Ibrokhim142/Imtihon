document.addEventListener('DOMContentLoaded', function() {
    const articlesContainer = document.getElementById('articlesContainer');

    fetch('https://blogpost-server-production-d92d.up.railway.app/api/v1/blogs')
        .then(response => response.json())
        .then(data => {
            if (data.data && data.data.length > 0) {
                data.data.forEach(article => {
                    const articleElement = document.createElement('div');
                    articleElement.classList.add('article');
                    articleElement.innerHTML = `
                        <a href="..//pages/product.html">
                            <img src="${article.image}" alt="${article.title}">
                        </a>
                        <h3>${article.title}</h3>
                        <p>${article.description}</p>
                        <strong>${article.tag}</strong>
                    `;
                    articlesContainer.appendChild(articleElement);
                    articleElement.addEventListener('click', () => {
                        console.log('Article clicked:', article.title);
                    });
                });
            } else {
                articlesContainer.innerHTML = '<p>No articles found.</p>';
            }
        })
        .catch(error => {
            console.error('Error fetching articles:', error);
            articlesContainer.innerHTML = '<p>Error fetching articles. Please try again later.</p>';
        });
});
